<?php

/* @var $this yii\web\View */

use yii\grid\GridView;

/* @var $searchModel frontend\models\CarSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$this->title = 'CarBuddy';
?>
<div class="site-index">

</div>
