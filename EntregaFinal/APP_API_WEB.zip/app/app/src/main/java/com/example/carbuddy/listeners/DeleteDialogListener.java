package com.example.carbuddy.listeners;

import com.example.carbuddy.models.Car;

import java.util.ArrayList;

/** Ficar à escuta do DeleteDialogListener **/
public interface DeleteDialogListener {
    void onDeleteYes(final int id);
}
