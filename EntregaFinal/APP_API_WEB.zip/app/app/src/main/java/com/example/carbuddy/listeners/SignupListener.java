package com.example.carbuddy.listeners;

import com.example.carbuddy.models.Login;

/** Ficar à escuta para atualizar o Signup **/
public interface SignupListener {
    void onSignup(boolean create);
}
