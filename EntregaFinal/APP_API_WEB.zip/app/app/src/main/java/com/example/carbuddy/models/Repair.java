package com.example.carbuddy.models;

import java.io.Serializable;

/**
 * Modelo Reapir, onde são definidos os getters, setters, construtores, propriedades e redefinição do método toString
 **/
public class Repair implements Serializable {
    private int id, kilometers, carId, contributorId;
    private String repairdate, repairdescription, state, repairtype;

    /**
     * Construtor da Repair
     **/
    public Repair(int id, int kilometers, int carId, int contributorId, String repairdate, String repairdescription, String state, String repairtype) {
        this.id = id;
        this.kilometers = kilometers;
        this.carId = carId;
        this.contributorId = contributorId;
        this.repairdate = repairdate;
        this.repairdescription = repairdescription;
        this.state = state;
        this.repairtype = repairtype;
    }

    //Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKilometers() {
        return kilometers;
    }

    public void setKilometers(int kilometers) {
        this.kilometers = kilometers;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public int getContributorId() {
        return contributorId;
    }

    public void setContributorId(int contributorId) {
        this.contributorId = contributorId;
    }

    public String getRepairDate() {
        return repairdate;
    }

    public void setRepairDate(String repairDate) {
        this.repairdate = repairDate;
    }

    public String getRepairDescription() {
        return repairdescription;
    }

    public void setRepairDescription(String repairDescription) {
        this.repairdescription = repairDescription;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getRepairtype() {
        return repairtype;
    }

    public void setRepairtype(String repairtype) {
        this.repairtype = repairtype;
    }

    /**
     * Redefinição do método toString
     **/
    @Override
    public String toString() {
        return "Repair{" +
                "id=" + id +
                ", kilometers=" + kilometers +
                ", carId=" + carId +
                ", contributorId=" + contributorId +
                ", repairDate='" + repairdate + '\'' +
                ", repairDescription='" + repairdescription + '\'' +
                ", state='" + state + '\'' +
                ", repairtype='" + repairtype + '\'' +
                '}';
    }
}
